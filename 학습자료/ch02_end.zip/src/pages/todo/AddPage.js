const AddPage = () => {


  return ( 
    <div className="text-3xl font-extrabold">
      Todo Add Page 
    </div> 
  );

}
 
export default AddPage;
